﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPAutomation
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text=="hp" && textBox2.Text=="wipro@123")
            {
                this.Hide();
                Menu m = new Menu();
                m.ShowDialog();
            }

            else
            {
                MessageBox.Show("Incorrect Username or Password!!!!!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
