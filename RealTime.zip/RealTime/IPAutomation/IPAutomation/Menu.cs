﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPAutomation
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SelectSeries s = new SelectSeries();
            this.Hide();
            s.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List l = new List();
            this.Hide();
            l.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            DeleteUser r =new DeleteUser();
            r.ShowDialog();
        }
    }
}
