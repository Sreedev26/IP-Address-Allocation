﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IPAutomation
{
    public partial class List : Form
    {
        public List()
        {
            InitializeComponent();
        }

        public void clear()
        {
            comboBox1.Text = "";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "128.88.152.XX")
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\RealTime\\152Series.accdb");
                con.Open();
                string sql = "select * from 152Series";
                OleDbDataAdapter ad = new OleDbDataAdapter(sql, con);
                DataSet ds = new DataSet();
                ad.Fill(ds, "152Series");
                dataGridView1.DataSource = ds.Tables["152Series"];
                dataGridView1.Visible = true;
                clear();
                con.Close();
            }


            if (comboBox1.Text == "128.88.153.XX")
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\RealTime\\153Series.accdb");
                con.Open();
                string sql = "select * from 153Series";
                OleDbDataAdapter ad = new OleDbDataAdapter(sql, con);
                DataSet ds = new DataSet();
                ad.Fill(ds, "153Series");
                dataGridView1.DataSource = ds.Tables["153Series"];
                dataGridView1.Visible = true;
                clear();
                con.Close();
            }

            if (comboBox1.Text == "128.88.154.XX")
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\RealTime\\154Series.accdb");
                con.Open();
                string sql = "select * from 154Series";
                OleDbDataAdapter ad = new OleDbDataAdapter(sql, con);
                DataSet ds = new DataSet();
                ad.Fill(ds, "154Series");
                dataGridView1.DataSource = ds.Tables["154Series"];
                dataGridView1.Visible = true;
                clear();
                con.Close();
            }

            if (comboBox1.Text == "10.200.90.XX")
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\RealTime\\90Series.accdb");
                con.Open();
                string sql = "select * from 90Series";
                OleDbDataAdapter ad = new OleDbDataAdapter(sql, con);
                DataSet ds = new DataSet();
                ad.Fill(ds, "90Series");
                dataGridView1.DataSource = ds.Tables["90Series"];
                dataGridView1.Visible = true;
                clear();
                con.Close();
            }

            if (comboBox1.Text == "10.200.91.XX")
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\RealTime\\91Series.accdb");
                con.Open();
                string sql = "select * from 91Series";
                OleDbDataAdapter ad = new OleDbDataAdapter(sql, con);
                DataSet ds = new DataSet();
                ad.Fill(ds, "91Series");
                dataGridView1.DataSource = ds.Tables["91Series"];
                dataGridView1.Visible = true;
                clear();
                con.Close();
            }

            if (comboBox1.Text == "10.200.92.XX")
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\RealTime\\92Series.accdb");
                con.Open();
                string sql = "select * from 92Series";
                OleDbDataAdapter ad = new OleDbDataAdapter(sql, con);
                DataSet ds = new DataSet();
                ad.Fill(ds, "92Series");
                dataGridView1.DataSource = ds.Tables["92Series"];
                dataGridView1.Visible = true;
                clear();
                con.Close();
            }

            if (comboBox1.Text == "10.200.93.XX")
            {
                OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\RealTime\\93Series.accdb");
                con.Open();
                string sql = "select * from 93Series";
                OleDbDataAdapter ad = new OleDbDataAdapter(sql, con);
                DataSet ds = new DataSet();
                ad.Fill(ds, "93Series");
                dataGridView1.DataSource = ds.Tables["93Series"];
                dataGridView1.Visible = true;
                clear();
                con.Close();
            }
        }
    }
}
