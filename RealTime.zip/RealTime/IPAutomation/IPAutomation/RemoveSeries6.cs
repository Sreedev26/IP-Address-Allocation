﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IPAutomation
{
    public partial class RemoveSeries6 : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\RealTime\\92Series.accdb");
        public RemoveSeries6()
        {
            InitializeComponent();
            updatecombobox();
        }


        public void updatecombobox()
        {
            string s = "select IPAddress from 92Series where Assigned ='Yes'";
            OleDbDataAdapter ad = new OleDbDataAdapter(s, con);
            con.Open();
            DataSet ds = new DataSet();
            ad.Fill(ds, "92Series");
            IPaddress_comboBox1.DisplayMember = "IPAddress";
            IPaddress_comboBox1.ValueMember = "IPAddress";
            IPaddress_comboBox1.DataSource = ds.Tables["92Series"];
            IPaddress_comboBox1.SelectedItem = null;
            IPaddress_comboBox1.Text = "--select--";
            con.Close();
        }
        public void clear()
        {

            IPaddress_comboBox1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IPaddress_comboBox1.SelectedItem != null)
            {
                try
                {
                    string s = "Update 92Series set Mailid ='', MacAddress='' , LocationDetails='' , PortDetails='', Requirement ='', ManagerID ='', Assigned = 'No' Where IPAddress = '" + IPaddress_comboBox1.SelectedValue + "'";
                    con.Open();
                    OleDbCommand com = new OleDbCommand(s, con);
                    int i = com.ExecuteNonQuery();
                    if (i == 1)
                    {
                        MessageBox.Show("Removed User", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("ERROR IN REMOVAL ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    con.Close();
                    updatecombobox();
                    clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }


            else
            {
                MessageBox.Show("Select IP Address", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            DeleteUser d = new DeleteUser();
            d.ShowDialog();
        }
    }
}
