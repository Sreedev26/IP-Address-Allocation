﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Data.OleDb;

namespace IPAutomation
{
    public partial class FirstSeries : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\RealTime\\152Series.accdb");
        public FirstSeries()
        {
            InitializeComponent();
            updatecombobox();
        }

        public void updatecombobox() {
            string s = "select IPAddress from 152Series where Assigned ='No'";
            OleDbDataAdapter ad = new OleDbDataAdapter(s, con);
            con.Open();
            DataSet ds = new DataSet();
            ad.Fill(ds, "152Series");
            IPaddress_comboBox1.DisplayMember = "IPAddress";
            IPaddress_comboBox1.ValueMember = "IPAddress";
            IPaddress_comboBox1.DataSource = ds.Tables["152Series"];
            IPaddress_comboBox1.SelectedItem = null;
            IPaddress_comboBox1.Text = "--select--";
            con.Close();
        }
        public void clear()
        {
            Mailid_textBox1.Text = "";
            MacAddress_textBox2.Text = "";
            Location_textBox3.Text = "";
            Port_textBox4.Text = "";
            Requirement_textBox5.Text = "";
            ManagerMail_textBox6.Text = "";
            IPaddress_comboBox1.Text = "";
        }

        public object ErrorProvider1 { get; private set; }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            SelectSeries s = new SelectSeries();
            s.ShowDialog();
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rEmail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

            if (Mailid_textBox1.Text.Length > 0 && Mailid_textBox1.Text.Trim().Length != 0)
            {
                if (!rEmail.IsMatch(Mailid_textBox1.Text.Trim()))
                {
                    MessageBox.Show("Please Enter a Valid mail ID");
                    Mailid_textBox1.SelectAll();
                    e.Cancel = true;
                }
            }


        }

        private void FirstSeries_Enter(object sender, EventArgs e)
        {
            
        }

        private void FirstSeries_Leave(object sender, EventArgs e)
        {

           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Mailid_textBox1.Text != "" && MacAddress_textBox2.Text != "" && Location_textBox3.Text != "" && Port_textBox4.Text != "" && Requirement_textBox5.Text != "" && ManagerMail_textBox6.Text != "" && IPaddress_comboBox1.SelectedItem != null )
            {
                try
                {
                    string s = "Update 152Series set Mailid = '" + Mailid_textBox1.Text + "', MacAddress = '" + MacAddress_textBox2.Text + "', LocationDetails = '" + Location_textBox3.Text + "', PortDetails = '" + Port_textBox4.Text + "', Requirement = '" + Requirement_textBox5.Text + "', ManagerID = '" + ManagerMail_textBox6.Text + "', Assigned = 'Yes' Where IPAddress = '" + IPaddress_comboBox1.SelectedValue + "'";
                    con.Open();
                    OleDbCommand com = new OleDbCommand(s, con);
                    int i = com.ExecuteNonQuery();
                    if (i == 1)
                    {
                        MessageBox.Show("Assigned IP", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else
                    {
                        MessageBox.Show("ERROR IN ASSIGNING IP", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    con.Close();
                    updatecombobox();
                    clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
               
            }


            else
            {
                MessageBox.Show("FILL ALL THE FIELDS WITH PROPER FORMAT", "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            
        }

        private void textBox6_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rEmail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

            if (ManagerMail_textBox6.Text.Length > 0 && ManagerMail_textBox6.Text.Trim().Length != 0)
            {
                if (!rEmail.IsMatch(ManagerMail_textBox6.Text.Trim()))
                {
                    MessageBox.Show("Please Enter a Valid mail ID");
                    ManagerMail_textBox6.SelectAll();
                    e.Cancel = true;
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
    }

